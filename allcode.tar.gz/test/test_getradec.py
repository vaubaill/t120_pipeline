

work_dir        = '/Volumes/BackUpMac/OHP/2017/2017-08-21/REDUCED/'
objcoo          = {'M33':['01 33 50','+30 39 37'],
                   '2002TX300':['01 22 01','+34 53 07'],
                   '73P':['03 13 57','+06 51 05'],
                   'P10CGCY':['00 58 46','-05 41 38'],
                   'TRITON':['22 58 49','-07 31 59'],
                   'PHOCAEA':['20 23 22','+24 32 30'],
                   'WOLF':['22 19 32','+21 44 54']}
t120_insert_radec(work_dir,objcoo)


work_dir        = '/Volumes/BackUpMac/OHP/2017/2017-08-22/REDUCED/'
objcoo          = {'AETHRA':['19 31 42','+03 47 45'],
                   'C2015VL62':['21 26 43','+04 04 47'],
                   'ERIS':['01 45 07','-02 17 36'],
                   'M74':['01 36  41','15 47 01'],
                   'P10CGCY':['01 00 46','-06 00 19'],
                   'TRITON':['22 58 38','-07 33 30'],
                   }
t120_insert_radec(work_dir,objcoo)

